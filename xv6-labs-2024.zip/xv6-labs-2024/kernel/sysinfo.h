#ifndef _sysinfo_h
#define _sysinfo_h

struct sysinfo {
    uint64 freemem;
    uint64 nproc;
};

#endif